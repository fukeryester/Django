from .views import logout, logon, login, forget_password
from django.urls import path

urlpatterns = [
    path('',login,name='login'),
    path('logon/',logon,name='logon'),
    path('logout/', logout, name='logout'),
    path('forget_password/', forget_password, name='forget_password'),
    # path('',views.HOMEView.as_view(), name='HOME'),
]
