from django.db import models

# Create your models here.
class Account(models.Model):
    password=models.CharField(max_length=200)
    email=models.CharField(max_length=20, primary_key=True)
    phone=models.CharField(max_length=20,null=True)
    nick_name=models.CharField(max_length=30,null=True)
    first_name=models.CharField(max_length=30,null=True)
    last_name=models.CharField(max_length=30,null=True)