from django.shortcuts import render,HttpResponse,redirect,reverse, HttpResponseRedirect
from login.models import Account
from django.contrib.auth.hashers import make_password
# Create your views here.


def login(request):
    if request.method == 'POST':
        print("进入页面")
        email = request.POST['username']
        password = request.POST['password']
        if email=='' or password=='':
            error = "邮箱/手机号或密码不能为空！"
            return render(request,'./log_in.html', {'error': error})
        
        corr_email = Account.objects.filter(email=email).first()
        corr_phone = Account.objects.filter(phone=email).first()
      
        if corr_email == None and corr_phone == None:
            error = "不存在该邮箱或手机号!"
            return render(request,'./log_in.html', {'error': error})
        if corr_email != None:
          if email == corr_email.email and password == corr_email.password:
            print('登录成功')
            request.session['email'] = email
            request.session["is_login"] = True
            request.session.set_expiry(24*60*60)
            return HttpResponseRedirect('/')
          else:
            error = "密码错误!"
            return render(request,'./log_in.html', {'error': error})
        if corr_phone != None:
          if email == corr_phone.email and password == corr_phone.password:
            print('登录成功')
            request.session['email'] = email
            request.session["is_login"] = True
            request.session.set_expiry(24*60*60)
            return HttpResponseRedirect('/')
          else:
            error = "密码错误!"
            return render(request,'./log_in.html', {'error': error})
    return render(request,'./log_in.html')

def logon(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        nick_name = request.POST.get('nick_name')
        password = request.POST.get('password')
        password_confirm = request.POST.get('repassword')
        if password != password_confirm:
            error = "两次输入密码不相同！请检查后重试"
            return render(request,'./log_on.html', {'error': error})
        elif len(password)<5 or len(email)<5:
            error = "密码或邮箱位数至少为5"
            return render(request,'./log_on.html', {'error': error})
        elif len(phone)!=11:
            error = "请确保手机号码位数正确！"
            return render(request,'./log_on.html', {'error': error})
        else:
            account = Account()
            account.email = email
            account.password = password
            account.phone = phone
            account.first_name = first_name
            account.last_name = last_name
            account.nick_name = nick_name
            account.save()
            return redirect(reverse('login'))
    return render(request,'./log_on.html')

def logout(request):
    del request.session['email']
    return redirect(reverse('login'))

def forget_password(request):
  if request.method == 'POST':
    request_email = request.POST.get('email')
    request_phone = request.POST.get('phone')
    request_firstname = request.POST.get('first_name')
    request_lastname = request.POST.get('last_name')
    password = request.POST.get('password')
    password_confirm = request.POST.get('repassword')
    try:
      # 获取具有特定email的Account对象
      account = Account.objects.get(email=request_email)
      if request_phone == account.phone or (request_firstname == account.first_name and request_lastname == account.last_name):
        if password != password_confirm:
          error = "两次输入密码不相同！请检查后重试"
          return render(request,'./forget_password.html', {'error': error})
        # 设置新的密码
        account.password = password
        # 保存修改后的Account对象
        account.save()
        # 打印成功消息或进行其他操作
        print("密码已成功修改！")
        return redirect(reverse('login'))
      else:
        error = "手机号或者您的全名认证失败！"
        return render(request,'./forget_password.html', {'error': error})
    except Account.DoesNotExist:
      # 处理邮箱不存在的情况
      error = "该邮箱不存在！"
      return render(request,'./forget_password.html', {'error': error})
  return render(request,'./forget_password.html')


def index(request):
    print("进入index")
    return redirect(reverse('login'))

