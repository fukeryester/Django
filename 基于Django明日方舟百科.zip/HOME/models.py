from django.db import models
from django.urls import reverse


# Create your models here.


class Operators(models.Model):
    """A typical class defining a model, derived from the Model class."""
    # Fields
    ID = models.CharField(max_length=4, primary_key=True, help_text='Enter ID')
    name = models.CharField(max_length=30, help_text='Enter name')
    sex = models.CharField(max_length=8, help_text='Enter sex')
    zhongzu = models.CharField(max_length=30, null=True, help_text='Enter zhongzu')
    occupation = models.CharField(max_length=8, help_text='Enter occupation', null=True)
    Zhenying = models.ForeignKey('Zhenying', on_delete=models.SET_NULL, null=True)
    zudang = models.IntegerField(null=True, help_text='Enter zudang')
    saying = models.TextField(null=True, max_length=400, help_text='Enter saying')
    bustURL = models.CharField(max_length=170, null=True, help_text='Enter bustURL')
    imageURL = models.CharField(max_length=170, null=True, help_text='Enter imageURL')
    vote_count = models.IntegerField(null=True, default=0)
    ...

    # Metadata
    class Meta:
        ordering = ['ID']


    def __str__(self):
        """String for representing the MyModelName object (in Admin site etc.)."""
        return self.name


# class Occupations(models.Model):
#     """A typical class defining a model, derived from the Model class."""
#     # Fields

#     occupation = models.CharField(max_length=8, primary_key=True, help_text='Enter occupation')

#     def __str__(self):
#         """String for representing the MyModelName object (in Admin site etc.)."""
#         return self.occupation


class Zhenying(models.Model):
    """A typical class defining a model, derived from the Model class."""
    # Fields
    name = models.CharField(max_length=16, primary_key=True, help_text='Enter name')
    intro = models.TextField(max_length=1000, help_text='Enter a brief description of the zhenying')


    def __str__(self):
        """String for representing the MyModelName object (in Admin site etc.)."""
        return self.name


class skin(models.Model):
    """A typical class defining a model, derived from the Model class."""
    # Fields
    name = models.CharField(max_length=32, help_text='Enter name')
    opID = models.ForeignKey('Operators', on_delete=models.SET_NULL, null=True)
    painter = models.CharField(max_length=32, help_text='Enter painter name')
    xilie = models.CharField(max_length=40, help_text='Enter xilie name')
    intro = models.TextField(max_length=1000, help_text='Enter a brief description of the skin')
    
    class Meta:
        unique_together=("name","opID")

    def __str__(self):
        """String for representing the MyModelName object (in Admin site etc.)."""
        return self.name





class Record(models.Model):
    """A typical class defining a model, derived from the Model class."""
    # Fields
    occupation = models.CharField(max_length=8, help_text='Enter occupation')

    def __str__(self):
        """String for representing the MyModelName object (in Admin site etc.)."""
        return self.occupation


class Jiaju(models.Model):
    """A typical class defining a model, derived from the Model class."""
    # Fields
    name = models.CharField(max_length=40, help_text='Enter name')
    miaoshu = models.CharField(max_length=200, help_text='Enter miaoshu')

    def __str__(self):
        """String for representing the MyModelName object (in Admin site etc.)."""
        return self.name
    

class user_op(models.Model):
    """A typical class defining a model, derived from the Model class."""
    # Fields
    user = models.ForeignKey('login.Account', on_delete=models.SET_NULL, null=True)
    op = models.ForeignKey('Operators', on_delete=models.SET_NULL, null=True)

    class Meta:
        unique_together=("user","op")

    
class user_jiaju(models.Model):
    """A typical class defining a model, derived from the Model class."""
    # Fields
    user = models.ForeignKey('login.Account', on_delete=models.SET_NULL, null=True)
    jiaju = models.ForeignKey('Jiaju', on_delete=models.SET_NULL, null=True)

    class Meta:
        unique_together=("user","jiaju")

