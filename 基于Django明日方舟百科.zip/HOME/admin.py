from django.contrib import admin
from . import models
from . import resource
from import_export.admin import ImportExportModelAdmin
# import csv
# from io import TextIOWrapper
# Register your models here.
# admin.site.register(models.Category)
# admin.site.register(models.Operators)
admin.site.register(models.Zhenying)
admin.site.register(models.Jiaju)
admin.site.register(models.user_jiaju)
admin.site.register(models.user_op)

class OperatorsAdmin(ImportExportModelAdmin):
    resource_class = resource.OperatorsResource
    fields=('ID', 'name','sex','zhongzu', 'occupation', 'Zhenying', 
           'zudang', 'saying', 'bustURL', 'imageURL')

class skinAdmin(ImportExportModelAdmin):
    resource_class = resource.skinResource
    fields=('name', 'opID','painter','xilie', 'intro')

admin.site.register(models.Operators, OperatorsAdmin)

admin.site.register(models.skin, skinAdmin)

# @admin.register(models.Operators)
# class OperatorsAdmin(admin.ModelAdmin):
#     list_display = ['ID', 'name', 'sex']
#     actions = ['import_csv']

#     def import_csv(self, request, queryset):
#         for file in request.FILES.getlist('csv_file'):
#             reader = csv.DictReader(TextIOWrapper(file.open(), 'utf-8'))
#             for row in reader:
#                 models.Operators.objects.create(
#                     ID=row['ID'],
#                     name=row['name'],
#                     sex=row['sex'],
#                     # 其他字段...
#                 )
#         self.message_user(request, "CSV数据导入成功！")

#     import_csv.short_description = "导入CSV数据"

# admin.site.register(OperatorsAdmin)