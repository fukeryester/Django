from django.urls import path
from . import views


urlpatterns = [
    path('', views.HOMEView.as_view(), name='HOME'),
    path('man/<int:ID>/', views.man, name='man'),
    path('skin1', views.skin1, name='skin1'),
    path('user_op_jiaju', views.opjiaju, name='opjiaju'),
]