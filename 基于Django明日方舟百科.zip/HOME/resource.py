from import_export import resources
from .models import Operators,skin

class OperatorsResource(resources.ModelResource):

    class Meta:
        model = Operators
        # exclude = ('id', )
        import_id_fields = ('ID', )
        fields=('ID', 'name','sex','zhongzu', 'occupation', 'Zhenying', 'zudang', 'saying', 'bustURL', 'imageURL')


class skinResource(resources.ModelResource):
    class Meta:
        model = skin
        # exclude = ['id']
        import_id_fields = ('name', 'opID')
        fields=('name', 'opID','painter','xilie', 'intro')