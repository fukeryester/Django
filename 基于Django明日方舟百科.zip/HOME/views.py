from django.shortcuts import render
from django.shortcuts import render,HttpResponse,redirect,reverse, HttpResponseRedirect
from django.views.generic import ListView, DetailView, CreateView, DeleteView, UpdateView
from login.models import Account
from . import models
import csv


# def import_csv(request):
#     with open('OPdata.csv') as f:
#         reader = csv.reader(f)
#         for row in reader:
#             obj = Operators()
#             obj.save()

# Create your views here.
class HOMEView(ListView):
    template_name = "HOME.html"
    model = models.Operators
    def get_context_data(self, **kwargs):
        account = Account.objects.all()
        context = super(HOMEView, self).get_context_data(**kwargs)
        context["account"] = account
        return context


def man(request, ID):
    operator = models.Operators.objects.get(ID=ID)
    if not request.session.get("email"): return HttpResponseRedirect('/login')
    else: return render(request, 'operator.html', locals())


def skin(request):
  return render(request, 'skin.html', local)

def skin1(request):
  skin = models.skin.objects.all()
  return render(request, 'skin1.html', {'skins':skin})

def opjiaju(request):
  if not request.session.get("email"): return HttpResponseRedirect('/login')
  else:
    email = request.session.get("email")
    jiaju = models.user_jiaju.objects.filter(user__email=email)
    op = models.user_op.objects.filter(user__email=email)
    return render(request, 'user_op_jiaju.html', {'email':email,'jiajus':jiaju,'ops':op})