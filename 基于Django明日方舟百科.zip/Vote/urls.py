from django.urls import path
from . import views


urlpatterns = [
    path('', views.VoteView, name='VoteView'),
    path('ShowResult', views.VoteShowRes, name='ShowResult'),

]