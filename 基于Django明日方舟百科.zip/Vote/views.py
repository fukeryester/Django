import random
from django.shortcuts import render
from django.http import JsonResponse
from HOME.models import Operators


def VoteView(request):
    operators = Operators.objects.all()
    selected_operators = random.sample(list(operators), 2)
    context = {
        'fst_optor': selected_operators[0],
        'snd_optor': selected_operators[1]
    }
    if request.method == 'POST':
        optor_name = request.POST['optor_name']
        operator = Operators.objects.filter(name=optor_name).first()
        if operator:
            vote_count = operator.vote_count
            vote_count += 1
            # 更新vote_count的值
            operator.vote_count = vote_count
            operator.save()
        else:
            # 处理找不到操作员的情况
            error = "No such Operator!"
            return render(request, 'Vote')
    return render(request, 'Vote_base.html', context)


def VoteShowRes(request):
    operators = Operators.objects.order_by('-vote_count')
    return render(request, 'Vote_show.html', {'operators': operators})

