function toggleSwitch() {
  //开关按钮
  var button = document.querySelector(".toggle-button");
  button.classList.toggle("active");

  //干员立绘平移
  var light = document.querySelector(".light");
  light.classList.toggle("slide-right");

  //干员信息慢慢浮现
  var fst_operatorInfo = document.querySelector(".fst_operator-info");
  fst_operatorInfo.classList.toggle("fade-in");

  //干员立绘平移
  var dark = document.querySelector(".dark");
  dark.classList.toggle("slide-left");

  //干员信息慢慢浮现
  var snd_operatorInfo = document.querySelector(".snd_operator-info");
  snd_operatorInfo.classList.toggle("fade-in");
  // 存储开关状态
  var toggleState = button.classList.contains("active") ? "on" : "off";
    localStorage.setItem("toggleState", toggleState);
  }
  
// 恢复开关状态
window.addEventListener("DOMContentLoaded", function() {
  var toggleState = localStorage.getItem("toggleState");
  if (toggleState === "on") {
    toggleSwitch();
  }
});
