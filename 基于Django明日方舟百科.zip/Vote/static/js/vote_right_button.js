document.getElementById("right_button").addEventListener("click", function () {
  this.innerHTML = '<ion-icon name="happy-outline"></ion-icon></ion-icon>';
  document.getElementById("left_button").innerHTML =
    '<ion-icon name="sad-outline"></ion-icon></ion-icon>';
  // 创建一个新的按钮
  var newButton = document.createElement("button");
  newButton.innerHTML = '<ion-icon name="reload-outline"></ion-icon>再来一组';
  // 设置新按钮的样式
  newButton.style.position = "relative";
  newButton.style.left = "20px";
  // 将新按钮添加到文档的右侧
  this.parentNode.appendChild(newButton);
  // 移除事件监听器，防止再次触发
  this.removeEventListener("click", arguments.callee);
  document
    .getElementById("left_button")
    .removeEventListener("click", arguments.callee);
  // 使两个按钮都不能再次被点击
  this.disabled = true;
  document.getElementById("left_button").disabled = true;
  // 添加新按钮的点击事件，使得点击后刷新页面
  newButton.addEventListener("click", function () {
    location.reload();
  });

});


